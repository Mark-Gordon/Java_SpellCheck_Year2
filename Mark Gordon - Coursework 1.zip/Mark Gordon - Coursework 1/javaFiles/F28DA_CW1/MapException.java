package F28DA_CW1;

public class MapException extends Exception{
	
	private String message;
	
	public MapException(String msg){
		message = msg;
	}
	
	public String getMessage(){
		return "Failed because : " + message;
	}

}
