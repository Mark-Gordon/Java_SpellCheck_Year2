package F28DA_CW1;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Map;

public class LinkedListMap  implements IMap{
	
	//LinkedList<String> ins = new LinkedList<String>();
	
	private LinkedList<String> list = new LinkedList<String>();
	
	public LinkedListMap(){
			
	};

	@Override
	public void insert(String key){
		
		list.add(key);
		
	}

	@Override
	public void remove(String key) throws MapException {
		
		if(list.contains(key)){
			list.remove(key);
		}else{
			throw new MapException("Map does not contain key");
		}
		
	}

	@Override
	public boolean find(String key) {
		
		if(list.contains(key)){
			return true;
		}
		
		return false;
	}

	@Override
	public int numberOfElements() {
		
		return list.size();
		
	}

	@Override
	public Iterator<String> elements() {
			
		return list.listIterator();
			
	}	
	
}
