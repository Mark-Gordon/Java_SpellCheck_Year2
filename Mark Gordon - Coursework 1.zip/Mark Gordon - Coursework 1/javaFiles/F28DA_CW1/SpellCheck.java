package F28DA_CW1;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;


/** Main class for the Spell-Checker program */
public class SpellCheck {
	
	private static Iterator<String> itr;
	
	//private static StringBuilder b = new StringBuilder();
	
	public static void main(String[] args) throws java.io.IOException, MapException{
		
		
		long start = System.currentTimeMillis();

		
		if (args.length != 2 ) {
			System.out.println("Usage: SpellCheck dictionaryFile.txt inputFile.txt ");
			System.exit(0);
		}

		try{
			BufferedInputStream dict;
			BufferedInputStream check;
			
			dict  = new BufferedInputStream(new FileInputStream(args[0]));
			check = new BufferedInputStream(new FileInputStream(args[1]));
				
			FileWordRead dictRead = new FileWordRead(dict);
			FileWordRead checkRead = new FileWordRead(check);
			
			//create object of HashCode
			StringHashCode sHC = new StringHashCode();
			
			HashTableMap dicMap = new HashTableMap(sHC, 1f);
			HashTableMap checkMap = new HashTableMap(sHC, 1f);
			
			//read dictionary file into map
			while(dictRead.hasNextWord()){
				dicMap.insert(dictRead.nextWord());
			}
			
			//read check/test file into map
			while(checkRead.hasNextWord()){
				checkMap.insert(checkRead.nextWord());
			}
		
			
			//create iterator of checkmap
			itr = checkMap.elements();
			
			//Arraylist used for holding the spelling corrections (Used to ensure no doubles are added to the stringbuilder)
			ArrayList<String> wordsAlreadyContained = new ArrayList<String>();
			
			//creates iterator of checkmap
			Iterator<String> itr = checkMap.elements();
			
			//loops over the number of elements in checkmap
			for(int index =0; index < checkMap.numberOfElements(); index++){

				
				
				//String builder used outputing the corrections
				StringBuilder b = new StringBuilder();
				
				//gets the next word to compare against the dictionary
				String next = itr.next();
				
				//Does all the checks
				LetterSub.letterSub(checkMap, dicMap, wordsAlreadyContained, next, b);	
				LetterOmission.letterOmission(checkMap, dicMap, wordsAlreadyContained, next, b);
				LetterInsertion.letterInsertion(checkMap, dicMap, wordsAlreadyContained, next, b);
				LetterReversal.letterReversal(checkMap, dicMap, wordsAlreadyContained, next, b);
				
				//prints out the word checked with the corrections
				//if length is 1 or over then it means a correction has been made
				if(b.length() >= 1){
					String toPrint = b.toString();
					toPrint = toPrint.replaceAll(", $", "");
					System.out.println(toPrint);
					
				}//close if statement
		
			}//close loop
			
			//not sure if it to be left in for the final program but have done so to be on the safe side
			
			long end = System.currentTimeMillis();
			
			System.out.println("time taken : " + ((end - start) /1000.0) + " seconds");
			
			dict.close();
			check.close();
			
			
		}//close try
		catch (IOException e){ // catch exceptions caused by file input/output errors
			System.out.println("Check your file name");
			System.exit(0);
		} //close catch
		
	}//close main method
	
}//close class

