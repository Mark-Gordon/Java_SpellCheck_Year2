package F28DA_CW1;

import java.util.ArrayList;
import java.util.Arrays;

public class LetterReversal {
	

	public static void letterReversal(HashTableMap checkMap, HashTableMap dicMap, ArrayList<String> wordsAlreadyContained, String next, StringBuilder b){
	
		//loop for length of word being checked -1 
		for(int j=0; j < next.length()-1; j++){
			
			//split word up into characters and put into arraylist
			ArrayList<String> list = new ArrayList<String>(Arrays.asList(next.split("")));
			
			//get character at j and store in temp
			String temp = list.get(j);
			
			//set character at j to j+1
			list.set(j, list.get(j+1));
			
			//set character at j+1 to j/temp
			list.set(j+1, temp);
			
			//build up string from the characters in list
			String s = BuildString.buildStr(list);
			
			//if string s can be found int he dictionary map and the word has not already been added then add it to the stringbuilder
			//and arraylist of words already contained
			if(dicMap.find(s) && !(wordsAlreadyContained.contains(s))){
				
				//if this is the first time the word is being correct then add to stringbuilder
				if(!(wordsAlreadyContained.contains(next + " => "))){
					wordsAlreadyContained.add(next + " => ");
					b.append(next + " => ");
				}
				
				b.append(s + ", ");
				wordsAlreadyContained.add(s);
			}
				
			
		}//close for loop
				
	}//close method

}//close class
