package F28DA_CW1;

import java.util.ArrayList;
import java.util.Arrays;

public class LetterSub {
	
	//static BuildString bs = new BuildString();
	
	public static void letterSub(HashTableMap checkMap, HashTableMap dicMap, ArrayList<String> wordsAlreadyContained, String next, StringBuilder b){
		
		
		//loops for length of word being checked
		for(int i=0; i < next.length(); i++){

			//split up word checking checked and store characters in arraylist
			ArrayList<String> list = new ArrayList<String>(Arrays.asList(next.split("")));
			
			//loops 26 times for each letter in alphabet
			for(int k=0; k < 26; k++){
				
				//will set first character to a through z 
				String charToAdd = Character.toString((char) (97 + k));
				
				//set character at i to charToAdd
				list.set(i, charToAdd);
				
				String s = BuildString.buildStr(list);
				
				//if string s can be found int he dictionary map and the word has not already been added then add it to the stringbuilder
				//and arraylist of words already contained
				if(dicMap.find(s) && !(wordsAlreadyContained.contains(s))){
					
					//if this is the first time the word is being correct then add to stringbuilder
					if(!(wordsAlreadyContained.contains(next + " => "))){
						wordsAlreadyContained.add(next + " => ");
						b.append(next + " => ");
					}
					
					b.append(s + ", ");
					wordsAlreadyContained.add(s);
				}	
			}//close looping through alphabet
			
		}//close looping through length of word
				

	}//close method

}//close class
