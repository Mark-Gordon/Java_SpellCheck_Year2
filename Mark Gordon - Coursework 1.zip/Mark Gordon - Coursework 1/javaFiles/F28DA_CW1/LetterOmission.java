package F28DA_CW1;

import java.util.ArrayList;
import java.util.Arrays;

public class LetterOmission {
	
	public static void letterOmission(HashTableMap checkMap, HashTableMap dicMap, ArrayList<String> wordsAlreadyContained, String next, StringBuilder b){
		
		//loop for length of the word being checked
		for(int k=0; k < next.length(); k++){
			
			//split word up into charaters and put into arraylist
			ArrayList<String> list = new ArrayList<String>(Arrays.asList(next.split("")));
			
			//remove character at position k
			list.remove(k);
			
			//build string up out of the characters in arraylist
			String s = BuildString.buildStr(list);
			
			//if string s can be found int he dictionary map and the word has not already been added then add it to the stringbuilder
			//and arraylist of words already contained
			if(dicMap.find(s) && !(wordsAlreadyContained.contains(s))){
				
				//if this is the first time the word is being correct then add to stringbuilder
				if(!(wordsAlreadyContained.contains(next + " => "))){
					wordsAlreadyContained.add(next + " => ");
					b.append(next + " => ");
				}
				
				b.append(s + ", ");
				wordsAlreadyContained.add(s);
			}
			
		}//close map loop
		
	}//close method

}//close class
