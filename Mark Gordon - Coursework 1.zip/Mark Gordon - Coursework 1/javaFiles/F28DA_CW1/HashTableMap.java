package F28DA_CW1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

public class HashTableMap implements IMap, IHashTableMonitor{

	//Data Structures and Algorithms in Java, 6th edition chap 10
	//and youtube tutorial https://www.youtube.com/watch?v=B4vqVDeERhI was used to gain an understanding of hashmaps so
	//code will follow a similar path to these two sources.

	private int numberOfOperations = 0;
	private int numberOfProbes = 0;
	private int itemsInArray = 0;
	private int arraySize = 7;
	private int oldArraySize = 5;

	float maxLoadFactor;

	String[] theArray = new String[arraySize];

	IHashCode doHash;


	public HashTableMap() throws MapException{
		throw new MapException("ERROR: Need to pass a hashcode object and maxium load factor!");
	}


	public HashTableMap(IHashCode inputCode, float maxLoadFactor){

		this.doHash = inputCode;

		this.maxLoadFactor = maxLoadFactor;

		//array is filled with -1 as placeholder, couldn't get to work while empty as checking if the the array at index i isempty resulted
		//in unexpected behaviour
		Arrays.fill(theArray, "-1");

	}


	@Override
	public float getMaxLoadFactor() {

		return maxLoadFactor;
	}

	@Override
	public float getLoadFactor() {
		return ((float) itemsInArray /(float) arraySize);
	}

	@Override
	public float averNumProbes() {
		return ((float) numberOfOperations / (float) numberOfProbes);
	}

	@Override
	public void insert(String key) throws MapException {

		numberOfOperations++;

		itemsInArray++;

		if(this.getLoadFactor() >= this.maxLoadFactor){

			increaseArraySize(arraySize);
		}

		//passes key to function to be double hashed
		doubleHashFunction(key);

	}

	@Override
	public void remove(String key) throws MapException {

		numberOfOperations++;

		//hashes the key to find the arrayindex to begin searching in
		int arrayIndex = doHash.giveCode(key, arraySize) % arraySize;

	    int stepDistance = oldArraySize - (doHash.giveCode(key, arraySize) % oldArraySize);

		//loop until key is found or arrayIndex is not equal to 1
		while(!(theArray[arrayIndex].equals("-1"))){

			if(theArray[arrayIndex].equals(key)){

				//"deleted" is inserted in as I couldn't get it to work with 'null' or ""
				theArray[arrayIndex] = "deleted";

				itemsInArray--;

				return;

			}

			arrayIndex+= stepDistance;

			arrayIndex %= arraySize;

		}

		throw new MapException("Key doesn't exist!");

	}

	@Override
	public boolean find(String key) {

		//this all follows a similar logic to the remove method only true the value contained is not altered
		//true is returned if its found, false if not

		numberOfOperations++;

		int arrayIndex = doHash.giveCode(key, arraySize) % arraySize;

		int stepDistance = oldArraySize - (doHash.giveCode(key, arraySize) % oldArraySize);

		while(!(theArray[arrayIndex].equals("-1"))){


			if(theArray[arrayIndex].equals(key)){
				return true;
			}


			arrayIndex+= stepDistance;

			arrayIndex %= arraySize;

		}

		return false;

	}

	@Override
	public int numberOfElements() {
		return itemsInArray;
	}

	@Override
	public Iterator<String> elements() {

		String[] returnArray = cleanArray(theArray);

		return Arrays.stream(returnArray).iterator();
	}

	private void doubleHashFunction(String input){

			//gives hash for place in arrayindex to store input
			int arrayIndex = doHash.giveCode(input, arraySize) ;

			int stepDistance = oldArraySize - (doHash.giveCode(input, arraySize) % oldArraySize);

			//if place in index is taken then increase arrayindex by stepdistance
			while(!(theArray[arrayIndex].equals("-1"))){

				numberOfProbes++;

				//System.out.println("?");


				arrayIndex+= stepDistance;// stepDistance;

				//arrayIndex++;
				//if arrayIndex is larger than arraysize then return the reminder when divided

				arrayIndex %= arraySize;


			}

			//place input in the array at arrayindex
			theArray[arrayIndex] = input;

	}

	private void increaseArraySize(int minArraySize){

		oldArraySize = minArraySize;

		// Get a prime number bigger than the current arraysize

		int newArraySize = getNextPrimeNumber(minArraySize);

		// Move the array into a bigger array with the larger prime number as the size

		createBiggerArray(newArraySize);

	}

	private int getNextPrimeNumber(int minNumberToCheck){

		//next prime number has to be at least double so the current arraySize is doubled

		minNumberToCheck *= 2;

		//loops until prime is found

		for (int i = minNumberToCheck; true; i++) {

			if (isPrimeNumber(i))
				return i;

		}

	}

	private boolean isPrimeNumber(int number){


		// Eliminate even numbers

		if (number % 2 == 0)
			return false;

		// Check if prime for all odd numbers

		for (int i = 3; i * i <= number; i += 2) {

			if (number % i == 0)
				return false;

		}

		return true;

	}

	private void createBiggerArray(int newArraySize){

		//removes empty space from array
		String[] cleanArray = cleanArray(theArray);


		theArray = new String[newArraySize];


		arraySize = newArraySize;


		fillArrayWithNeg1();

		//adds to the new array
		for(String theString: cleanArray){
			doubleHashFunction(theString);
		}

	}

	private String[] cleanArray(String[] arrayToClean){


		ArrayList<String> stringList = new ArrayList<String>();

		//adds each value to the arraylist excluding the ones with value "-1" and "deleted"
		for (String theString : arrayToClean)
			if (!theString.equals("-1") && !theString.equals("deleted"))
				stringList.add(theString);

		return stringList.toArray(new String[stringList.size()]);


	 }


	public void fillArrayWithNeg1() {

		Arrays.fill(theArray, "-1");

	}


}
