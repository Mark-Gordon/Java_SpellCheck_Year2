package F28DA_CW1;

import java.util.ArrayList;

public class BuildString {
	
	//used to build up the string which will print out the word checked and the corrections
	
	public static String buildStr(ArrayList<String> list){
		
		StringBuilder builder = new StringBuilder();
		for(String s : list) {
		    builder.append(s);
		}
		
		
		return builder.toString();
		
		
	}

}
