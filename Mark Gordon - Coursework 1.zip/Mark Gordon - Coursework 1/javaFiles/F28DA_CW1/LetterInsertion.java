package F28DA_CW1;

import java.util.ArrayList;
import java.util.Arrays;

public class LetterInsertion {
	
public static void letterInsertion(HashTableMap checkMap, HashTableMap dicMap, ArrayList<String> wordsAlreadyContained, String next, StringBuilder b){
		
		
		//loop for length of word being checked +1
		for(int j=0; j < next.length()+1; j++){
			
			//loops for each letter in the alphabet
			for(int k=0; k < 26; k++){
				
				//will pick the char to add. Starting with 'a' the first loop and ending in 'z'
				String charToAdd = Character.toString((char) (97 + k));
				
				//splits word into its characters and puts it into an arraylist
				ArrayList<String> list = new ArrayList<String>(Arrays.asList(next.split("")));
				
				//adds character charToAdd at the position j
				list.add(j, charToAdd);
				
				//builds the string from the arraylist adding all the characters to make one string
				String s = BuildString.buildStr(list);
				
				//if string s can be found int he dictionary map and the word has not already been added then add it to the stringbuilder
				//and arraylist of words already contained
				if(dicMap.find(s) && !(wordsAlreadyContained.contains(s))){
					
					//if this is the first time the word is being correct then add to stringbuilder
					if(!(wordsAlreadyContained.contains(next + " => "))){
						wordsAlreadyContained.add(next + " => ");
						b.append(next + " => ");
					}
					
					b.append(s + ", ");
					wordsAlreadyContained.add(s);
				}

				
			}//close loop of alphabet
			
			
		}// close loop of word length +1
		
		
	}//close method

}//close class

