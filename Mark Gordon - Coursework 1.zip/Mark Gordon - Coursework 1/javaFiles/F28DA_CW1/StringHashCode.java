package F28DA_CW1;

public class StringHashCode implements IHashCode{
	

	@Override
	public int giveCode(Object o, int arraySize) {

		int hashVal = 0;
        
        for (int i = 0; i < o.toString().length(); i++) {

            hashVal = (39 * hashVal + o.toString().charAt(i)) % arraySize;
        	
        }
        
        return hashVal;
		
	
	}
	
	

}
